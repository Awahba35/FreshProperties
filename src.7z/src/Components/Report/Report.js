import React, { Component } from 'react';
import {BrowserRouter} from 'react-router-dom';

class Report extends Component {
  render() {
    return (

      <div className="container">
      <div class="input-group mb-3">
  <div class="input-group-prepend">
    <label class="input-group-text" for="inputGroupSelect01">Options</label>
  </div>
  <select class="custom-select" id="inputGroupSelect01">
    <option selected>Choose...</option>
    <option value="1">General Maitenance</option>
    <option value="2">Electrical</option>
    <option value="3">HVAC</option>
    <option value="4">Plumbing</option>
  </select>
</div>
<br/>
<br/>
<p>* Please describe the request </p>
<br/>
<textarea rows="4" cols="50">
</textarea>
<br/>
<br/>
<button type="button" class="btn btn-success">Submit</button>
<br/>
     </div>
    );
  }
}

export default Report;
