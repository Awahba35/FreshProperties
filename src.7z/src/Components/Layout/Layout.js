import React, { Component } from 'react';
import Header from '../Header/Header';
import SignUp from '../Sign-up/SignUp';
import {Route,Redirect } from 'react-router-dom';
import AboutUs from '../AboutUs/AboutUs';
import Home from '../Home/Home';
import PayRent from '../PayRent/PayRent';
import Report from '../Report/Report';
class Layout extends Component {
    state = {
        isUserLoggedIn: false,
    }
    //Change variable name from event to isValidUser
    signInSubmissionHandler = (isValidUser) => {
        this.setState(
            {
                isUserLoggedIn: isValidUser
            }
        );
 
    }
    render() {
        let routes = (
            <React.Fragment>
                <Route exact path="/about-us" component={AboutUs} />
                <Route exact path="/sign-Up" component={SignUp} />
                <Route exact path="/" component={Home} />
                

            </React.Fragment>
        );
        if(this.state.isUserLoggedIn){
             routes = (
                <React.Fragment>
                    <Route exact path="/pay-rent" component={PayRent} />
                    <Route exact path="/Home" component={Home} />
                    <Route exact path="/report" component={Report} />
                    <Route exact path="/" component={Home} />
                    
                </React.Fragment> 
            );
        }
        return (
            <div>
                <React.Fragment>

                    <Header isUserLoggedIn={this.state.isUserLoggedIn} submitHandler={this.signInSubmissionHandler} />

                {routes}

                </React.Fragment>
            </div>
        )
    }
}

export default Layout;